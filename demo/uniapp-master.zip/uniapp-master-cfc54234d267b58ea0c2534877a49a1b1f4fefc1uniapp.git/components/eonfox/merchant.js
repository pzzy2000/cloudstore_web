/* 商家模块 */
var merchant = function(){};
merchant.prototype = {
	
	constructor : merchant,
	
	//收银员的订单列表是否需要刷新
	cashierOrderListRefresh : false
	
};

export default merchant;