//测试数据
const listData = [{
	header_img: "http://cs.zhangkaixing.com/face/face_2.jpg",
	user_name: "测试1",
	rate:5,
	create_time: "2019-04-12",
	content: "好评",
	imgs:[
		'/com/face/face.jpg',
		'http://cs.zhangkaixing.com/face/p10.jpg',
		'http://cs.zhangkaixing.com/face/face_14.jpg',
		'http://cs.zhangkaixing.com/face/face.jpg',
		'http://cs.zhangkaixing.com/face/p10.jpg',
	]
},
{
	content: "中评",
	create_time: "2019-04-12",
	header_img: "http://cs.zhangkaixing.com/face/face_12.jpg",
	user_name: "测试2",
	rate:4,
	// imgs:[]
},
{
	content: "",
	create_time: "2019-04-12",
	header_img: "http://cs.zhangkaixing.com/face/face_15.jpg",
	user_name: "测试3",
	rate:2,
	// imgs:[]
},{
	content: "好评",
	create_time: "2019-04-12",
	header_img: "http://cs.zhangkaixing.com/face/face_2.jpg",
	user_name: "测试1",
	rate:5,
	imgs:[
		'http://cs.zhangkaixing.com/face/face.jpg',
		'http://cs.zhangkaixing.com/face/p10.jpg',
		'http://cs.zhangkaixing.com/face/face_14.jpg',
		'http://cs.zhangkaixing.com/face/face.jpg',
		'http://cs.zhangkaixing.com/face/p10.jpg',
	]
},
{
	content: "中评",
	create_time: "2019-04-12",
	header_img: "http://cs.zhangkaixing.com/face/face_12.jpg",
	user_name: "测试2",
	rate:3.5,
	// imgs:[]
},
{
	content: "",
	create_time: "2019-04-12",
	header_img: "http://cs.zhangkaixing.com/face/face_15.jpg",
	user_name: "测试3",
	rate:2.3,
	// imgs:[]
}]

export default listData