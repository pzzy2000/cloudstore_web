<template>
	<view class="content">
		<view class="collection">
			<view class="container_of_slide" v-for="(item, index) in lists" :key="index">
				<view class="slide_list">
					<view class="now-message-info" hover-class="uni-list-cell-hover">
						<view class="icon-circle">
							<image class='goods-img' :src="item.icon" mode="aspectFill"></image>
						</view>
						<view class="list-right">
							<view class="list-title">昵称: {{ item.nickname }}</view>
							<view class="list-detail color-6">手机号: {{ item.phone }}</view>
							<view class="list-detail">推荐时间: {{ item.createTime |formatCreateTime}}</view>
						</view>
					</view>
					<view style="clear:both"></view>
				</view>
			</view>
			<uni-load-more :status="loadStatus"></uni-load-more>
		</view>
	</view>
</template>

<script>
import mallplusCopyright from '@/components/mall-copyright/mallplusCopyright.vue';
import Api from '@/common/api';
import uniLoadMore from '@/components/uni-load-more/uni-load-more.vue'
import { formatDate } from '@/common/date';
export default {
	components: {
		uniLoadMore
	},
	data() {
		return {
			lists: [],
			page: 1, //当前页
			limit: 10, //每页显示几条
			loadStatus: 'more'
		};
	},
	onLoad () {
		this.getShareCode();
		this.getDataList();
	},
	onReachBottom () {
		if (this.loadStatus === 'more') {
			this.getDataList()
		}
	},
	filters: {
                  formatCreateTime(time) {
                    let date = new Date(time);
                    return formatDate(date, 'yyyy-MM-dd hh:mm:ss')
                  },
                },
	methods: {
	async	getDataList() {
			let params = {  };
                        				let data = await Api.apiCall('get', Api.member.inviteUser, params);
                        				console.log(data)
                        				this.lists = data;
		},
		//获取邀请码
		getShareCode(){
			let userToken = this.$db.get("userToken");
			if (userToken && userToken != '') {
				// 获取我的分享码
				this.$api.shareCode({}, res => {
					if (res.status) {
						this.myShareCode = res.data;
					}
				});
			}
		}
	},
};
</script>

<style scoped>
.collection .goods-img{
	width: 150upx;
	height: 150upx;
}
.container_of_slide {
	width: 100%;
	overflow: hidden;
}
.slide_list {
	transition: all 100ms;
	transition-timing-function: ease-out;
	min-width: 100%;
}
.now-message-info {
	box-sizing:border-box;
	display: flex;
	align-items: center;
	font-size: 16px;
	clear:both;
	padding: 20upx 26upx;
	margin-bottom: 2upx;
	background: #FFFFFF;
	width: 100%;
}
.now-message-info,
.group-btn {
	float: left;
}
.group-btn {
	display: flex;
	flex-direction: row;
	height: 190upx;
	min-width: 100upx;
	align-items: center;

}
.group-btn .btn-div {
	height: 190upx;
	color: #fff;
	text-align: center;
	padding: 0 50upx;
	font-size: 34upx;
	line-height: 190upx;
}
.group-btn .top {
	background-color: #FF7159;
}
.group-btn .removeM {
	background-color: #999;
}
.icon-circle{
	width:150upx;
	height: 150upx;
	float: left;
}
.list-right{
	float: left;
	margin-left: 25upx;
	height: 150upx;
}
.list-right-1{
	float: right;
	color: #A9A9A9;
}
.list-title{
	width: 490upx;
	line-height:1.5;
	overflow:hidden;
	color:#333;
	font-size: 26upx;
	min-height: 60upx;
}
.list-detail{
	width: 460upx;
	font-size: 24upx;
	color: #a9a9a9;
	display:-webkit-box;
	-webkit-box-orient:vertical;
	-webkit-line-clamp:1;
	overflow:hidden;
	height: 50upx;
}
</style>
