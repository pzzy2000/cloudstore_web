'use strict'
module.exports = {
  NODE_ENV: '"production"',
  BASE_API: '"http://51wangshi.com:8085"'
}
