<template> 
    <adminDayStatics-detail :is-edit='false'>
</adminDayStatics-detail>
</template>
<script>
    import AdminDayStaticsDetail from './components/detail'

    export default {
        name: 'addAdminDayStatics',
        components: {AdminDayStaticsDetail}
    }
</script>
<style>
</style>


