<template> 
    <dict-detail :is-edit='false'>
</dict-detail>
</template>
<script>
    import DictDetail from './components/DictDetail'

    export default {
        name: 'addDict',
        components: {DictDetail}
    }
</script>
<style>
</style>


