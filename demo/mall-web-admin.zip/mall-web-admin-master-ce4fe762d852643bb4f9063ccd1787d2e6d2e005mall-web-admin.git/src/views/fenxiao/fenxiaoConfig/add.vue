<template> 
    <fenxiaoConfig-detail :is-edit='false'>
</fenxiaoConfig-detail>
</template>
<script>
    import FenxiaoConfigDetail from './components/detail'

    export default {
        name: 'addFenxiaoConfig',
        components: {FenxiaoConfigDetail}
    }
</script>
<style>
</style>


