<template> 
    <fenxiaoConfig-detail :is-edit='true'>
</fenxiaoConfig-detail>
</template>
<script>
    import FenxiaoConfigDetail from './components/detail'

    export default {
        name: 'updateFenxiaoConfig',
        components: {FenxiaoConfigDetail}
    }
</script>
<style>
</style>


