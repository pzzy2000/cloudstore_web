<template> 
    <fenxiaoChecks-detail :is-edit='false'>
</fenxiaoChecks-detail>
</template>
<script>
    import FenxiaoChecksDetail from './components/detail'

    export default {
        name: 'addFenxiaoChecks',
        components: {FenxiaoChecksDetail}
    }
</script>
<style>
</style>


