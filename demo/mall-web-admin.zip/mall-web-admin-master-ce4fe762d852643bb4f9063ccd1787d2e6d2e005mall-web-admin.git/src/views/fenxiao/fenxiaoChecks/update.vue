<template> 
    <fenxiaoChecks-detail :is-edit='true'>
</fenxiaoChecks-detail>
</template>
<script>
    import FenxiaoChecksDetail from './components/detail'

    export default {
        name: 'updateFenxiaoChecks',
        components: {FenxiaoChecksDetail}
    }
</script>
<style>
</style>


