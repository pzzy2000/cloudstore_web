<template> 
    <fenxiaoUserRelate-detail :is-edit='true'>
</fenxiaoUserRelate-detail>
</template>
<script>
    import FenxiaoUserRelateDetail from './components/detail'

    export default {
        name: 'updateFenxiaoUserRelate',
        components: {FenxiaoUserRelateDetail}
    }
</script>
<style>
</style>


