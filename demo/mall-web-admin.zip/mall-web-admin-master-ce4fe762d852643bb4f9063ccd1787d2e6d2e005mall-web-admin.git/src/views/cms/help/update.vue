<template> 
  <help-detail :is-edit='true'></help-detail>
</template>
<script>
  import HelpDetail from './components/HelpDetail'
  export default {
    name: 'updateHelp',
    components: { HelpDetail }
  }
</script>
<style>
</style>


