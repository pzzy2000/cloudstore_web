<template> 
  <prefrenceArea-detail :is-edit='true'></prefrenceArea-detail>
</template>
<script>
  import PrefrenceAreaDetail from './components/PrefrenceAreaDetail'
  export default {
    name: 'updatePrefrenceArea',
    components: { PrefrenceAreaDetail }
  }
</script>
<style>
</style>


