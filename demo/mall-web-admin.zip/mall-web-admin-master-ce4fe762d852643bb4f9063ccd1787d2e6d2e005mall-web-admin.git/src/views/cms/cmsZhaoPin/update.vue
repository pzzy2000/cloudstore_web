<template> 
    <cmsZhaoPin-detail :is-edit='true'>
</cmsZhaoPin-detail>
</template>
<script>
    import CmsZhaoPinDetail from './components/detail'

    export default {
        name: 'updateCmsZhaoPin',
        components: {CmsZhaoPinDetail}
    }
</script>
<style>
</style>


