<template> 
  <subjectComment-detail :is-edit='false'></subjectComment-detail>
</template>
<script>
  import SubjectCommentDetail from './components/SubjectCommentDetail'
  export default {
    name: 'addSubjectComment',
    components: { SubjectCommentDetail }
  }
</script>
<style>
</style>


