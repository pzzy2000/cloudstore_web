<template> 
  <smallNaviconCategory-detail :is-edit='true'></smallNaviconCategory-detail>
</template>
<script>
  import SmallNaviconCategoryDetail from './components/SmallNaviconCategoryDetail'
  export default {
    name: 'updateSmallNaviconCategory',
    components: { SmallNaviconCategoryDetail }
  }
</script>
<style>
</style>


