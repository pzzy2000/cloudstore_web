<template> 
  <FeightTemplateDetail :is-edit='false'></FeightTemplateDetail>
</template>
<script>
  import FeightTemplateDetail from './components/FeightTemplateDetail'
  export default {
    name: 'addFeightTemplateDetail',
    components: { FeightTemplateDetail }
  }
</script>
<style>
</style>


