<template> 
    <omsPayments-detail :is-edit='false'>
</omsPayments-detail>
</template>
<script>
    import OmsPaymentsDetail from './components/detail'

    export default {
        name: 'addOmsPayments',
        components: {OmsPaymentsDetail}
    }
</script>
<style>
</style>


