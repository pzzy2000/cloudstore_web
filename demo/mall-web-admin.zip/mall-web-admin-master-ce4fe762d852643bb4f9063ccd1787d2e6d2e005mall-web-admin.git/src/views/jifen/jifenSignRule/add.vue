<template> 
    <jifenSignRule-detail :is-edit='false'>
</jifenSignRule-detail>
</template>
<script>
    import JifenSignRuleDetail from './components/detail'

    export default {
        name: 'addJifenSignRule',
        components: {JifenSignRuleDetail}
    }
</script>
<style>
</style>


