<template> 
    <jifenSignRule-detail :is-edit='true'>
</jifenSignRule-detail>
</template>
<script>
    import JifenSignRuleDetail from './components/detail'

    export default {
        name: 'updateJifenSignRule',
        components: {JifenSignRuleDetail}
    }
</script>
<style>
</style>


