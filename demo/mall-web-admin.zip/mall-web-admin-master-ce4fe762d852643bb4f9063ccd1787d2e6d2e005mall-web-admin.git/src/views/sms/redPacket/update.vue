<template> 
  <redPacket-detail :is-edit='true'></redPacket-detail>
</template>
<script>
  import RedPacketDetail from './components/RedPacketDetail'
  export default {
    name: 'updateRedPacket',
    components: { RedPacketDetail }
  }
</script>
<style>
</style>


