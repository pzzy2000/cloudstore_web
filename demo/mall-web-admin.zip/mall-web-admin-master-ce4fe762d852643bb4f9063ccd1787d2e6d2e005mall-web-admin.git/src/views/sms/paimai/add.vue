<template> 
  <PaiMaiDetail :is-edit='false'></PaiMaiDetail>
</template>
<script>
  import PaiMaiDetail from './components/PaimaiDetail'
  export default {
    name: 'addPaiMaiDetail',
    components: { PaiMaiDetail }
  }
</script>
<style>
</style>


