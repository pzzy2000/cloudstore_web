<template> 
  <PaiMaiDetail :is-edit='true'></PaiMaiDetail>
</template>
<script>
  import PaiMaiDetail from './components/PaimaiDetail'
  export default {
    name: 'updatePaiMaiDetail',
    components: { PaiMaiDetail }
  }
</script>
<style>
</style>


