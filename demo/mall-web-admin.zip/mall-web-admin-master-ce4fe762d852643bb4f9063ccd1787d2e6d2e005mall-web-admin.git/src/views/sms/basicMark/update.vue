<template> 
 <baseMark-detail :isEdit="false"></baseMark-detail>
</template>
<script>
  import BaseMarkDetail from './components/BaseMarkDetail'
  export default {
    name: 'updateBaseMark',
    components: { BaseMarkDetail }
  }
</script>
<style></style>


