<template> 
    <smsContent-detail :is-edit='false'>
</smsContent-detail>
</template>
<script>
    import SmsContentDetail from './components/detail'

    export default {
        name: 'addSmsContent',
        components: {SmsContentDetail}
    }
</script>
<style>
</style>


