<template> 
    <smsContent-detail :is-edit='true'>
</smsContent-detail>
</template>
<script>
    import SmsContentDetail from './components/detail'

    export default {
        name: 'updateSmsContent',
        components: {SmsContentDetail}
    }
</script>
<style>
</style>


