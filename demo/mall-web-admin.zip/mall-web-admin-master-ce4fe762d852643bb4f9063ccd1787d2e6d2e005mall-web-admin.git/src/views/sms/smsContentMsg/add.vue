<template> 
    <smsContentMsg-detail :is-edit='false'>
</smsContentMsg-detail>
</template>
<script>
    import SmsContentMsgDetail from './components/detail'

    export default {
        name: 'addSmsContentMsg',
        components: {SmsContentMsgDetail}
    }
</script>
<style>
</style>


