<template> 
  <DrawDetail :is-edit='false'></DrawDetail>
</template>
<script>
  import DrawDetail from './components/DrawDetail'
  export default {
    name: 'addDrawDetail',
    components: { DrawDetail }
  }
</script>
<style>
</style>


