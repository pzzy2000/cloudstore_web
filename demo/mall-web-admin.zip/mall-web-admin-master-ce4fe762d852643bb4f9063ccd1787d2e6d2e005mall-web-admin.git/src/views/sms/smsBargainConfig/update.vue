<template> 
    <smsBargainConfig-detail :is-edit='true'>
</smsBargainConfig-detail>
</template>
<script>
    import SmsBargainConfigDetail from './components/detail'

    export default {
        name: 'updateSmsBargainConfig',
        components: {SmsBargainConfigDetail}
    }
</script>
<style>
</style>


