<template> 
  <SmsBasicGifts-detail :isEdit="false"></SmsBasicGifts-detail>
</template>
<script>
  import SmsBasicGiftsDetail from './components/SmsBasicGiftsDetail'
  export default {
    name: 'addSmsBasicGifts',
    components: { SmsBasicGiftsDetail }
  }
</script>
<style></style>


